/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
* Name:		Austin Rafuls									   *
* Project:	Casino Project 1 : C++							   *
* Class:	CMPS 366 - Organization of Programming Languages   *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
#include "Casino.h"

int main()
{
	Casino casino;				// Init the entire instance of casino
	casino.StartMenu();			// Prompt user with start menu

	return 0;
}